---
name: flipping-real-estate-assistant
description: "Use when working Alexey's real-estate flip projects."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [flipping, real-estate, renovation, design, tula, project-assistant]
---

# Flipping Real-Estate Assistant

Hermes acts as **design assistant + technical helper** on Alexey's real-estate
flipping deals (his #1 priority business: buy low, renovate, sell fast for margin).

## Core principle (always apply)

> Renovation-for-sale must be **neutral, light, technically reliable, mass-market
> friendly**. Every single decision is tested by ONE question:
> **does it raise the sale price / speed up the sale — or does it only raise the estimate?**

- Goal is NOT a bespoke interior. It is a liquid apartment that sells fast at max
  controlled-budget margin. If a decision only inflates the estimate, cut it.
- Pick one **neutral/light/soft-Scandinavian** direction: warm-white/light-gray
  walls, light-oak floor, one dark-metal accent used sparingly. Three-color rule.
- Hard "do-nots": no re-planning just for design, no kitchen/bath relocation, no
  load-bearing demolition, no colorful/dark/designer tiles, no complex ceilings,
  no over-investing in custom furniture, no finishing a balcony before the slab
  is verified.

## Financial discipline (private seller)

- For a **private seller**, renovation costs do NOT reduce the tax base: NDFL 13%
  is levied on (sale − purchase price). Per-calc: NDFL = 13% × (sale − purchase).
- If activity becomes **systematic** (multiple flips/year), tax status is at risk —
  flag USN/entity planning early, not at year-end.
- **Cycle time dominates ROI.** Annualized = cycle_return × (12/cycle_months).
  A deal that's "great" at a 2-month cycle collapses at 5–6 months. Separate the
  portion you control (renovation speed) from the portion you don't (sale time =
  market exposure). Always push to validate probable days-on-market, not just build time.
- Built-in margins: if a repair claims a +20–40% price gain, it's credible ONLY if
  the unit was bought **below market** (auction/bankruptcy/liquidation). Bought at
  market → validate the target sale price hard against live comparables.

## Sale price validation (always do this)

- A target price is an anchor, not a plan, until checked against **3–5 live
  comparable listings** in the SAME district: same type, ~same m², renovated.
- **Top-floor risk is a SALES risk**, not just a repair one: top-floor units
  systematically sell slower and at a 3–10% discount. If the target price equals
  a good mid-floor price, the top floor may be at the ceiling of its range → longer
  exposure → cycle blows out.

## Comparables research (pitfall + working path)

- Russian classifieds (CIAN, Yandex.Realty, Avito) block automated BROWSERS: CIAN →
  WAF ("подозрительный трафик"), Yandex → SmartCaptcha, Avito → VPN dialog / misleading
  "page doesn't exist". Do NOT treat "no results" as "no listings" — it's bot detection.
- **Working path found (PREFERRED): the mobile Avito endpoint `m.avito.ru` serves complete
  structured data** (`window.__initialData__`: price, price/m², area, floor, district, address,
  new/secondary marker) with working pagination — far richer and cleaner than CIAN. Recipe +
  data-extraction notes in `references/avito-mobile-scrape.md`. Try this FIRST for comparables.
- CIAN's legacy `cat.php` endpoint also serves listings to plain `curl` even when the
  interactive site blocks the browser; recipe + extraction notes in
  `references/cian-scrape-comparables.md`. Useful as a second source, but its data is noisier
  (mixed cities, loose price/address binding).
- Other aggregators: n1.ru & etagi.com return HTTP 200 but are JS shells (no data
  server-side for curl); domclick needs auth (401). Prefer the Avito mobile path above.
- If scraping is blocked/unreliable, ask Alexey to paste listing links/screenshots.

### Clickable Avito links for the user (do this)
- Comparable prices differ MOST by renovation state, not district — two units on the
  SAME street can differ by 200–500k or even 2× (e.g. Smidovich 8 at 83k/m² vs
  Smidovich 4 at 170k/m²) purely on condition. Numbers alone blind the user to this.
- So when presenting comparables, ALWAYS also emit clickable Avito links so Alexey can
  open photos and judge renovation himself. Build the link from the card's `uri`,
  stripping the messy `?context=...` param:
  ```python
  def avito_link(uri):
      path = re.match(r'^([^?]+)', uri or '').group(1)
      return "https://www.avito.ru" + path
  # /tula/kvartiry/2-k._kvartira_448_m_55_et._7207378935?context=... ->
  # https://www.avito.ru/tula/kvartiry/2-k._kvartira_448_m_55_et._7207378935
  ```
- The agent's own curl gets Avito's safety block (HTTP 439) on these desktop links even
  though the IP is Russian — that's fine: Alexey opens them in HIS browser (live RU IP).
  The links are valid; data collection already happens via m.avito.ru. Group the closest
  matches (same top-floor, ~same m²) as "direct analogues" with a link each.

### Pinterest as a design-reference source
- Pinterest WORKS through the agent's browser (vision can read pin photos). Useful to pull
  renovation/kitchen references (e.g. "small white kitchen + wood") for staging decisions.
- Quirk: logging into Pinterest in the USER's local browser does NOT carry over to the
  agent's separate cloud browser (different session/cookies). Don't promise the agent
  "sees" the user's logged-in boards. Basic pin search works unauthenticated — enough to
  gather references; to match the user's taste, have him send board/pin links to analyze.

## Floor-plan reading & visual verification (pitfalls, learned on Фрунзе 17)

- **The memo is NOT the source of truth — the client's own data is.** In 2026-08 the
  Фрунзе memo claimed «санузел раздельный», but Alexey's hand-drawn sketch showed a
  COMBINED с/у (2.9 м²), and he explicitly said the memo is «корявый». Always confirm
  geometry (rooms, doors, windows, balcony) against the client's sketch/photos BEFORE
  building estimates and visualizations.
- **Hand-sketch symbol key (Alexey's rule):** rectangle with an X inside = DOOR; rectangle
  WITHOUT an X, with an arrow or «ОКНО» label = WINDOW. Vision models routinely confuse
  these — what looks like «a door from the bedroom to the balcony» on the sketch is often
  an arrow pointing at the bedroom window.
- **Vision is unreliable on faded/small blueprints — one reading is never enough.** It
  hallucinates areas (8.4 м² kitchen vs real 6.0), door counts, window counts, и балкон
  «под тремя комнатами». Working pattern: boost contrast (1.4–1.5×), upscale ×2 (LANCZOS),
  cut into overlapping 2×2/3×3 crops (±40–60 px overlap), ask ONE focused question per
  crop, then reconcile with the client's confirmations. The client's word is final.
- **Image generation (gemini-flash) defaults to «pretty» wrong geometry:** it draws
  open-plan kitchens (illegal with a gas stove!) and long balconies spanning several rooms
  even with explicit «separate enclosed kitchen» / «balcony under living room only»
  prompts. Always: (1) put the constraint in the prompt verbatim — «enclosed SEPARATE
  kitchen, own wall and door, no open plan, no bar counter», «balcony under X only, not
  under kitchen»; (2) verify EVERY render via vision BEFORE showing the client;
  (3) treat renders strictly as style sketches («как выглядит направление»), never as an
  exact blueprint; (4) state the generator's idealization (expensive tech, perfect
  furniture) explicitly.
- **For an exact copy of a plan, draw it programmatically (PIL), don't generate it.**
  Deterministic, matches the sketch 1:1. Reusable helpers (Cyrillic-aware walls/doors/
  windows, crop recipe for vision): `references/plan-redraw-pil.md`.

## Role: business partner × designer (adds a visual layer)

Beyond numbers, Alexey wants the visual/design dimension too — treat the deal as one
linked decision chain and present it that way:

```
How it looks (design)  →  Out of what + cost (procurement)  →  Pays off for sale? (margin/speed)
```

- In this role, produce actual **design-project output**: 2–3 named design directions
  (e.g. light Scandinavian, Japandi warm stone, neutral white-gray), each with palette,
  a generated visualization, tech solution (layout, where sockets, which tile) and estimate.
- Run every reference/idea through the brief's decision table:
  | Приём из референса | Что даёт визуально | Оценка стоимости | Окупаемость | Решение |
  with decision options: берём как есть / упрощённо / бюджетный аналог / не берём.
  Pinterest shows expensive effects that a cheaper analogue reproduces ~80% of the time —
  flag which ones to simplify.
- Balance it against margin: a prettier option that costs +60k and adds nothing to sale
  price gets cut or simplified; the same look for less wins. The bottom-line question is
  always the classic one (does it raise price/speed, or just the estimate?).
- The agent's own eyes come from the configured OpenRouter vision model; generation model
  draws the visualizations. See `references/openrouter-vision-generator-models.md` for
  vision-vs-generation model selection, availability checks, and config keys.

## Renovation scope decisions (from the Tula brief)

- Isolated rooms + separate bathroom = market advantage → KEEP layout, don't replan.
- If gas stove present, kitchen/room unification is legally hard → skip it.
- Small kitchens (6 m²): G/L-shaped compact, uppers to ceiling, light facades, light
  worktop, integrated fridge, good task lighting; avoid dark facades & open shelves.
- Electrics/plumbing: replace apartment-level wiring to copper + new board + RCDs;
  replace shutoff valves + distribution. Photograph cable/pipe routes before closing.
- Budget ~620–650k for 43 m² worked; reserve the top of budget for hidden defects
  (roof, balcony slab, risers, floor level). Targeting the low end + reserve is the
  disciplined play.

## Working style with Alexey

- He communicates in Russian and wants **reasoning + analysis also in Russian**, not
  just the final reply. Mental "thinking" is English by default for models — make an
  effort to keep delivered analysis/thoughts in Russian.
- He values **honest pushback**: give the flip side, point out where he may be wrong.
  He explicitly does NOT want the assistant to always agree. Present pluses AND minuses.
- Direct, friendly, on "ты". No hype, no tech-evaneglism — practicality and honesty.
- Practical: if the idea is average, say where the weakness is, in plain words.

## Project file organization (Obsidian vault)

- Alexey's vault: `D:\HERMES FILES\HERMES OBSIDIAN`. Each flip property gets a folder
  `Недвижимость\<Объект>\` (e.g. `Недвижимость\Фрунзе 17\`) with fixed subfolders:
  `Планировка/` (BTI/эскизы), `Фото/` (photos + references), `Аналитика_аналоги/`
  (scrape dumps from m.avito.ru). The working memo is `ФЛИППИНГ_<Объект>_мемо.md`
  inside the property folder; `Недвижимость.md` is the overview card linking each
  property via `[[wikilink]]`; each property also has an index card `<Объект>.md`
  (финансы, статус-чек-лист) linking to the memo. Keep the status checkboxes current.
- When Alexey drops new files for a property (план/фото), sort them into this
  structure instead of the workspace root.

## Cyrillic file pitfalls (this Windows workspace)

- `search_files` with a Cyrillic filename glob (e.g. `*мемо*`, `*Фрунзе*`) can return
  0 hits even when the file exists. Working fallback: `find . -iname "*..."` in terminal.
- `read_file` may misdetect a valid UTF-8 Cyrillic .md as "Binary file". Verify with
  `file <name>` (it will say UTF-8) and read via terminal `cat`. Don't trust `iconv`
  guesses (UTF-16LE/CP1251) before checking `xxd` — they produced garbage on a plain
  UTF-8 file.

## Project references

- `references/openrouter-vision-generator-models.md` — vision vs image-generation model
  selection on OpenRouter, model-availability checks, and the Hermes config keys that run
  the agent's eyes + visualizations. (Vision = image→text for "seeing" plans/photos; a
  model page existing does NOT mean it's in the API catalog — verify with `/models/{id}`.)
- `references/tula-frunze-17.md` — current live flip: 43.2 m², 2-room, 5/5, 1966 brick,
  u. Frunze 17, Sovetsky r-n, Tula. **Confirmed 2026-08: purchase 3.9M** (user corrected the
  4.0M in the brief), renovation 650k, target sale 5.6M. Live comparables (702 secondary
  listings, 33 Sovetsky analogues) put the target at the TOP of a 5.3–5.6M corridor; net
  ~721k at 5.6M (ROI 15.8%/cycle). Same Frunze-17 object listed on Avito at 3.9M → bought
  AT market, not below. Full matrix + sources: `references/tula-frunze-17.md`.